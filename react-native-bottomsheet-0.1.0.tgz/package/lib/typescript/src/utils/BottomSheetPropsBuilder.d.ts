import { type BottomSheetProps } from '../components/BottomSheet';
interface BottomSheetOwnProps extends Pick<BottomSheetProps, 'expandable' | 'fullscreen' | 'snapPointsCollapsed' | 'snapPointsExpanded' | 'backdropOpacity' | 'backdropColor' | 'backgroundColor' | 'borderRadius' | 'handleColor' | 'showHandle' | 'animationDuration' | 'closeOnBackdropTap' | 'panSnapPoints' | 'onClose' | 'scrollViewContentContainerStyle'> {
}
export declare class BottomSheetPropsBuilder {
    private props;
    private constructor();
    static one(): BottomSheetPropsBuilder;
    withExpandable(value: BottomSheetOwnProps['expandable']): this;
    withFullscreen(value: BottomSheetOwnProps['fullscreen']): this;
    withSnapPointsCollapsed(value: BottomSheetOwnProps['snapPointsCollapsed']): this;
    withSnapPointsExpanded(value: BottomSheetOwnProps['snapPointsExpanded']): this;
    withBackdropOpacity(value: BottomSheetOwnProps['backdropOpacity']): this;
    withBackdropColor(value: BottomSheetOwnProps['backdropColor']): this;
    withBackgroundColor(value: BottomSheetOwnProps['backgroundColor']): this;
    withBorderRadius(value: BottomSheetOwnProps['borderRadius']): this;
    withHandleColor(value: BottomSheetOwnProps['handleColor']): this;
    withShowHandle(value: BottomSheetOwnProps['showHandle']): this;
    withAnimationDuration(value: BottomSheetOwnProps['animationDuration']): this;
    withCloseOnBackdropTap(value: BottomSheetOwnProps['closeOnBackdropTap']): this;
    withPanSnapPoints(value: BottomSheetOwnProps['panSnapPoints']): this;
    withOnClose(value: BottomSheetOwnProps['onClose']): this;
    withScrollViewContentContainerStyle(value: BottomSheetOwnProps['scrollViewContentContainerStyle']): this;
    build(): Partial<BottomSheetOwnProps>;
}
export {};
//# sourceMappingURL=BottomSheetPropsBuilder.d.ts.map