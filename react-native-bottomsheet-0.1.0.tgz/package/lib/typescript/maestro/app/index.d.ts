declare function HomeScreen(): import("react/jsx-runtime").JSX.Element;
export default HomeScreen;
//# sourceMappingURL=index.d.ts.map